# Donor Connect

## 📌 Description
A platform to connect blood donors and recipients.

## 🚀 Features
- Donor registration
- Search donors
- Request blood

## 🛠️ Technologies
- HTML,CSS,JS 

## ▶️ How to Run
1. Download ZIP
2. Extract files
3. Open index.html (or run backend if exists)

## 👥 Team Members
- Nishika
- Navya
- Maha
